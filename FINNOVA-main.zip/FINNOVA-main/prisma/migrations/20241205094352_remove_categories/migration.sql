/*
  Warnings:

  - You are about to drop the column `category` on the `budgets` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "budgets" DROP COLUMN "category";
